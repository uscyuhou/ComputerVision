
import cv2
import xml.etree.ElementTree as ET


if __name__ == '__main__':

    # Define a function to calculate the iou, intersection over union

    def IoU(boxA, boxB):
        # print boxA, boxB

        xA = max(boxA[0], boxB[0])
        yA = max(boxA[1], boxB[1])
        xB = min(boxA[2], boxB[2])
        yB = min(boxA[3], boxB[3])

        interArea = max(0, xB - xA) * max(0, yB - yA)




        boxAArea = (boxA[2] - boxA[0]) * (boxA[3] - boxA[1])
        boxBBrea = (boxB[2] - boxB[0]) * (boxB[3] - boxB[1])

        iou = interArea / float(boxAArea + boxBBrea - interArea)

        # return the intersection over union value
        return iou

    def IoUCompare(boxA,list):
        # boxA is proposed rect, list is ground truth list
        for elem in list:
            if IoU(elem,boxA) > 0.5:
                return True
        return False

    # Read xml file

    tree = ET.parse('HW2_ImageData/boundingbox_groudntruths/2007_002953.xml')
    objects = tree.findall('object')

    print tree.findtext('xmin')


    groundTruth = []
    for object in objects:
        bndbox = object.find('bndbox')
        xmin = bndbox.findtext('xmin')
        ymin = bndbox.findtext('ymin')
        xmax = bndbox.findtext('xmax')
        ymax = bndbox.findtext('ymax')
        groundTruth.append([int(xmin),int(ymin),int(xmax),int(ymax)])
    print groundTruth

    print IoU(groundTruth[0],groundTruth[1])
    print IoU([1,1,3,3],[2,2,4,4])


    cv2.setUseOptimized(True)
    cv2.setNumThreads(4)

    # read image
    im = cv2.imread('HW2_ImageData/Images/2007_002953.jpg')


    # create Selective Search Segmentation SS object
    ss = cv2.ximgproc.segmentation.createSelectiveSearchSegmentation()

    # create a color strategy
    color = cv2.ximgproc.segmentation.createSelectiveSearchSegmentationStrategyColor()
    # create other strategies
    texture = cv2.ximgproc.segmentation.createSelectiveSearchSegmentationStrategyTexture()
    fill = cv2.ximgproc.segmentation.createSelectiveSearchSegmentationStrategyFill()
    size = cv2.ximgproc.segmentation.createSelectiveSearchSegmentationStrategySize()
    multi = cv2.ximgproc.segmentation.createSelectiveSearchSegmentationStrategyMultiple(texture,color,fill,size)


    # feed an image into SS object
    # single: color
    ss.clearStrategies()
    ss.addStrategy(color)
    ss.setBaseImage(im)
    #
    # feed an image into SS object
    # # multiple
    # ss.clearStrategies()
    # ss.addStrategy(multi)
    # ss.setBaseImage(im)

    # high recall slow mood
    ss.switchToSelectiveSearchQuality()

    # fast mood
    ss.switchToSelectiveSearchFast()

    # run selective search segmentation on input image
    bboxes = ss.process()
    print('Total Number of Proposals: {}'.format(len(bboxes)))

    # number of region proposals to show
    numShowRects = 100

    # create a copy of original image
    imOut = im.copy()

    # print ground truth
    for elem in groundTruth:
        cv2.rectangle(imOut, (elem[0], elem[1]), (elem[2], elem[3]), (0, 0, 255), 1, cv2.LINE_AA)

    # itereate over all the region proposals
    for i, rect in enumerate(bboxes):
        # draw rectangle for region proposal till numShowRects
        if (i < numShowRects):
            x, y, w, h = rect
            if IoUCompare([x, y, x + w, y + h], groundTruth) == True:
                cv2.rectangle(imOut, (x, y), (x + w, y + h), (255, 0, 0), 1, cv2.LINE_AA)
            else:
                cv2.rectangle(imOut, (x, y), (x + w, y + h), (0, 255, 0), 1, cv2.LINE_AA)

            # cv2.putText(imOut, "IoU: {:.4f}".format(iou), (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        else:
            break

    # show output
    cv2.imshow("Output", imOut)
    cv2.waitKey(0)
    # close image show window
    cv2.destroyAllWindows()

