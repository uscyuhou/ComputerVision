

######################################################################
import cv2

img = cv2.imread('HW2_ImageData/Images/2007_000464.jpg')
img = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)

img = cv2.pyrMeanShiftFiltering(img, 80, 120, 1)
img = cv2.cvtColor(img, cv2.COLOR_LAB2BGR)

cv2.imshow('img2',img)
cv2.waitKey(0)

